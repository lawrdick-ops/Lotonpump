export const RPC_URL =
  process.env.NEXT_PUBLIC_SOLANA_RPC_URL || "https://api.devnet.solana.com";

export const NETWORK =
  process.env.NEXT_PUBLIC_SOLANA_NETWORK || "devnet";

export const TREASURY_WALLET =
  process.env.NEXT_PUBLIC_TREASURY_WALLET || "11111111111111111111111111111111";

export const DAILY_WALLET =
  process.env.NEXT_PUBLIC_DAILY_WALLET || TREASURY_WALLET;

export const WEEKLY_WALLET =
  process.env.NEXT_PUBLIC_WEEKLY_WALLET || TREASURY_WALLET;

export const DEV_WALLET =
  process.env.NEXT_PUBLIC_DEV_WALLET || TREASURY_WALLET;
