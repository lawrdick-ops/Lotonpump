import { DAILY_WALLET, DEV_WALLET, WEEKLY_WALLET } from "@/lib/config";

export const stats = [
  { label: "Daily Prize Pool", value: "14.5 SOL", accent: "text-emerald-300" },
  { label: "Weekly Jackpot", value: "132.7 SOL", accent: "text-amber-300" },
  { label: "Tickets Sold Today", value: "3,240", accent: "text-cyan-300" },
  { label: "Entries Verified", value: "98.7%", accent: "text-fuchsia-300" }
];

export const wallets = [
  { title: "Daily Lotto Wallet", amount: "8.2 SOL", desc: "Used to fund daily reward payouts.", address: DAILY_WALLET },
  { title: "Weekly Jackpot Wallet", amount: "115.4 SOL", desc: "Grows throughout the week for the main draw.", address: WEEKLY_WALLET },
  { title: "Dev & Ops Wallet", amount: "32.5 SOL", desc: "Supports development, marketing, and operations.", address: DEV_WALLET }
];

export const steps = [
  { title: "Connect Wallet", text: "Use Phantom or another Solana wallet to join the platform." },
  { title: "Buy Entries", text: "Choose a ticket bundle and approve the SOL payment." },
  { title: "Verify Transaction", text: "The backend checks the transfer destination and amount." },
  { title: "Record Entry", text: "Verified entries can then be saved into your real database in the next step." }
];

export const winners = [
  { date: "Mar 15", draw: "Daily", wallet: "7sF...A9d", prize: "12 SOL", proof: "#" },
  { date: "Mar 14", draw: "Daily", wallet: "9Ke...X3a", prize: "10 SOL", proof: "#" },
  { date: "Mar 13", draw: "Daily", wallet: "8Na...7Pk", prize: "9 SOL", proof: "#" },
  { date: "Mar 12", draw: "Weekly", wallet: "4Tr...M2p", prize: "45 SOL", proof: "#" }
];

export const ticketBundles = [
  { id: "t1", label: "1 Ticket", priceSol: 0.015, price: "0.015 SOL", bonus: "Base entry" },
  { id: "t5", label: "5 Tickets", priceSol: 0.070, price: "0.070 SOL", bonus: "Best starter pack" },
  { id: "t10", label: "10 Tickets", priceSol: 0.130, price: "0.130 SOL", bonus: "+ bonus chance" }
];

export const missions = [
  "Follow us on X",
  "Repost launch post",
  "Join Telegram",
  "Invite friends"
];
