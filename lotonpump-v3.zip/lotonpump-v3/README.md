# $LOT v3 – wallet connect + real SOL transfer + verification API

This version adds:
- Solana wallet connect
- real SOL transfer using `sendTransaction`
- backend API route to verify the transfer
- env-based treasury wallet setup
- safer default config on **devnet**

## Setup

### 1. Install
```bash
npm install
```

### 2. Create env file
Copy `.env.example` to `.env.local` and replace the wallet addresses.

### 3. Use devnet first
Default RPC is devnet:
```bash
NEXT_PUBLIC_SOLANA_RPC_URL=https://api.devnet.solana.com
NEXT_PUBLIC_SOLANA_NETWORK=devnet
```

### 4. Run
```bash
npm run dev
```

## Deploy on Vercel
- Push to GitHub
- Import repo in Vercel
- Add the same env variables there

## Important limitations
This version verifies the payment, but it still does **not**:
- save entries to a database
- create daily/weekly draw records
- pay winners automatically
- show live wallet balances from chain

## Best next step
Version 4 should add:
- Supabase/Postgres
- `entries` table
- actual draw windows
- backend-created entry records after verification
- admin panel / winner export

## Legal / practical note
Use devnet for testing first. Before using mainnet or public prize mechanics, make sure the setup matches the laws and platform rules that apply to you.
