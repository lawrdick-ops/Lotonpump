import { Footer } from "@/components/footer";
import { Hero } from "@/components/hero";
import { HowItWorks } from "@/components/how-it-works";
import { MissionsSection } from "@/components/missions-section";
import { Navbar } from "@/components/navbar";
import { StatsGrid } from "@/components/stats-grid";
import { TicketSection } from "@/components/ticket-section";
import { WalletsSection } from "@/components/wallets-section";
import { WinnersSection } from "@/components/winners-section";

export default function Page() {
  return (
    <main className="min-h-screen text-white selection:bg-amber-300 selection:text-black">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(circle_at_top,rgba(255,200,87,0.14),transparent_28%),radial-gradient(circle_at_20%_30%,rgba(56,189,248,0.1),transparent_20%),radial-gradient(circle_at_80%_70%,rgba(217,70,239,0.08),transparent_20%)]" />
      <div className="mx-auto max-w-7xl px-6 py-6 md:px-10">
        <Navbar />
        <Hero />
        <StatsGrid />
        <HowItWorks />
        <TicketSection />
        <WalletsSection />
        <WinnersSection />
        <MissionsSection />
        <Footer />
      </div>
    </main>
  );
}
