import "./globals.css";
import "@solana/wallet-adapter-react-ui/styles.css";
import type { Metadata } from "next";
import { WalletProviders } from "@/components/wallet-providers";

export const metadata: Metadata = {
  title: "$LOT v3 | Ticket Purchase Flow",
  description: "Next.js + Solana wallet connect + ticket purchase flow."
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <WalletProviders>{children}</WalletProviders>
      </body>
    </html>
  );
}
