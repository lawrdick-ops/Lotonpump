import { NextRequest, NextResponse } from "next/server";
import { Connection, PublicKey } from "@solana/web3.js";
import { RPC_URL, TREASURY_WALLET } from "@/lib/config";

type VerifyBody = {
  signature?: string;
  expectedLamports?: number;
};

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as VerifyBody;

    if (!body.signature || !body.expectedLamports) {
      return NextResponse.json({ ok: false, message: "Missing signature or expectedLamports." }, { status: 400 });
    }

    const connection = new Connection(RPC_URL, "confirmed");
    const tx = await connection.getParsedTransaction(body.signature, {
      maxSupportedTransactionVersion: 0
    });

    if (!tx || !tx.meta || !tx.transaction) {
      return NextResponse.json({ ok: false, message: "Transaction not found." }, { status: 404 });
    }

    const treasury = new PublicKey(TREASURY_WALLET).toBase58();

    const transferInstruction = tx.transaction.message.instructions.find((ix) => {
      return "parsed" in ix && ix.program === "system" && ix.parsed?.type === "transfer";
    });

    if (!transferInstruction || !("parsed" in transferInstruction)) {
      return NextResponse.json({ ok: false, message: "No system transfer found." }, { status: 400 });
    }

    const info = transferInstruction.parsed.info as {
      destination: string;
      lamports: number;
      source: string;
    };

    if (info.destination !== treasury) {
      return NextResponse.json({ ok: false, message: "Destination wallet does not match treasury." }, { status: 400 });
    }

    if (Number(info.lamports) !== Number(body.expectedLamports)) {
      return NextResponse.json({ ok: false, message: "Transfer amount does not match bundle price." }, { status: 400 });
    }

    return NextResponse.json({
      ok: true,
      signature: body.signature,
      amountLamports: info.lamports,
      destination: info.destination,
      source: info.source,
      message: "Transaction verified successfully."
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown verification error.";
    return NextResponse.json({ ok: false, message }, { status: 500 });
  }
}
