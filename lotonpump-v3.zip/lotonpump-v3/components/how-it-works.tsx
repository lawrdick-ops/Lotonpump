import { steps } from "@/lib/data";

export function HowItWorks() {
  return (
    <section id="how" className="pb-16">
      <div className="mb-8 flex items-center gap-3">
        <div className="section-line" />
        <h2 className="text-center text-3xl font-black tracking-tight md:text-4xl">How It Works</h2>
        <div className="section-line-reverse" />
      </div>

      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
        {steps.map((step, idx) => (
          <div key={step.title} className="card p-6 transition hover:-translate-y-1">
            <div className="mb-5 inline-flex h-14 w-14 items-center justify-center rounded-2xl border border-amber-300/20 bg-amber-300/10 text-xl font-bold text-amber-200">
              {idx + 1}
            </div>
            <h3 className="text-xl font-bold">{step.title}</h3>
            <p className="mt-3 leading-7 text-white/65">{step.text}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
