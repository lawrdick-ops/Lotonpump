import Link from "next/link";
import { WalletConnectButton } from "@/components/wallet-connect-button";

export function Navbar() {
  return (
    <header className="sticky top-4 z-20 mb-10 rounded-2xl border border-white/10 bg-white/5 px-4 py-4 backdrop-blur-xl">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="text-4xl font-black tracking-tight">
          <span className="bg-gradient-to-r from-amber-300 to-yellow-500 bg-clip-text text-transparent">
            $LOT
          </span>
        </div>

        <nav className="flex flex-wrap items-center gap-3 text-sm text-white/75">
          <Link href="#how" className="transition hover:text-white">How It Works</Link>
          <span className="text-amber-400">◆</span>
          <Link href="#tickets" className="transition hover:text-white">Tickets</Link>
          <span className="text-amber-400">◆</span>
          <Link href="#wallets" className="transition hover:text-white">Wallets</Link>
          <span className="text-amber-400">◆</span>
          <Link href="#winners" className="transition hover:text-white">Winners</Link>
        </nav>

        <WalletConnectButton />
      </div>
    </header>
  );
}
