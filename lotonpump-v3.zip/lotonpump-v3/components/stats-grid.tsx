import { stats } from "@/lib/data";

export function StatsGrid() {
  return (
    <section className="grid gap-4 pb-16 md:grid-cols-2 xl:grid-cols-4">
      {stats.map((item) => (
        <div key={item.label} className="card p-[1px] shadow-[0_0_30px_rgba(255,255,255,0.04)]">
          <div className="rounded-2xl bg-[#0b0f14]/95 px-6 py-6">
            <p className="text-sm uppercase tracking-[0.2em] text-white/45">{item.label}</p>
            <div className={`mt-3 text-4xl font-black tracking-tight ${item.accent}`}>{item.value}</div>
          </div>
        </div>
      ))}
    </section>
  );
}
