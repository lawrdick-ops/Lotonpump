import { wallets } from "@/lib/data";
import { shortAddress } from "@/lib/utils";

export function WalletsSection() {
  return (
    <section id="wallets" className="pb-16">
      <div className="mb-4 flex items-center gap-3">
        <div className="section-line" />
        <h2 className="text-center text-3xl font-black tracking-tight md:text-4xl">Transparent Prize Wallets</h2>
        <div className="section-line-reverse" />
      </div>

      <p className="mx-auto mb-8 max-w-3xl text-center text-white/65">
        Replace the placeholder env values with your real wallet addresses.
      </p>

      <div className="grid gap-5 lg:grid-cols-3">
        {wallets.map((wallet) => (
          <div key={wallet.title} className="card p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold">{wallet.title}</h3>
                <p className="mt-3 max-w-sm leading-7 text-white/65">{wallet.desc}</p>
              </div>
              <div className="rounded-2xl border border-amber-300/20 bg-amber-300/10 px-4 py-2 text-sm font-semibold text-amber-200">
                Public
              </div>
            </div>

            <div className="mt-8 text-5xl font-black tracking-tight text-amber-300">{wallet.amount}</div>
            <div className="mt-4 text-sm text-white/50">{shortAddress(wallet.address)}</div>

            <a
              href={`https://solscan.io/account/${wallet.address}${wallet.address === "11111111111111111111111111111111" ? "" : ""}`}
              target="_blank"
              className="mt-8 inline-flex rounded-xl border border-white/10 bg-white/5 px-5 py-3 font-medium transition hover:bg-white/10"
            >
              View on Solscan
            </a>
          </div>
        ))}
      </div>
    </section>
  );
}
