import { missions } from "@/lib/data";

export function MissionsSection() {
  return (
    <section className="pb-24">
      <div className="mb-4 flex items-center gap-3">
        <div className="section-line" />
        <h2 className="text-center text-3xl font-black tracking-tight md:text-4xl">Community Missions</h2>
        <div className="section-line-reverse" />
      </div>

      <p className="mx-auto mb-8 max-w-3xl text-center text-white/65">
        Bonus entry missions can be connected later to X, Telegram, and referrals.
      </p>

      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {missions.map((mission) => (
          <button key={mission} className="card px-6 py-5 text-left font-semibold transition hover:bg-white/10">
            {mission}
          </button>
        ))}
      </div>
    </section>
  );
}
