import { Countdown } from "@/components/countdown";
import { NETWORK } from "@/lib/config";

export function Hero() {
  const target = new Date(Date.now() + 1000 * 60 * 60 * 2 + 1000 * 60 * 11 + 1000 * 19).toISOString();

  return (
    <section className="grid items-center gap-10 pb-12 lg:grid-cols-[1.05fr_1fr] lg:pb-20">
      <div className="relative">
        <div className="mx-auto aspect-square max-w-[520px] rounded-full border border-amber-300/20 bg-[radial-gradient(circle_at_center,rgba(255,208,92,0.2),rgba(8,10,16,0.95)_58%)] p-5 shadow-[0_0_80px_rgba(251,191,36,0.15)]">
          <div className="relative flex h-full items-center justify-center rounded-full border-8 border-amber-400/30 bg-[#0a0d12]">
            <div className="absolute inset-4 rounded-full border border-white/10" />
            <div className="absolute inset-8 rounded-full bg-[conic-gradient(from_0deg,#f59e0b_0_12%,#0f172a_12%_25%,#22c55e_25%_37%,#111827_37%_50%,#a855f7_50%_62%,#0f172a_62%_75%,#06b6d4_75%_87%,#111827_87%_100%)] opacity-90 blur-[1px]" />
            <div className="absolute top-4 z-10 h-0 w-0 border-l-[18px] border-r-[18px] border-b-[34px] border-l-transparent border-r-transparent border-b-amber-300" />
            <div className="relative z-10 h-24 w-24 rounded-full border-8 border-amber-300/50 bg-gradient-to-b from-amber-200 to-amber-500 shadow-[0_0_35px_rgba(251,191,36,0.45)]" />
          </div>
        </div>
      </div>

      <div>
        <p className="mb-4 inline-flex rounded-full border border-amber-300/20 bg-amber-300/10 px-4 py-2 text-sm font-medium text-amber-200">
          Ticket flow demo • {NETWORK}
        </p>
        <h1 className="max-w-3xl text-5xl font-black leading-tight tracking-tight md:text-6xl">
          Wallet Connect.
          <br />
          Ticket Purchase.
          <br />
          <span className="bg-gradient-to-r from-amber-200 via-yellow-400 to-amber-500 bg-clip-text text-transparent">
            Verification Ready.
          </span>
        </h1>
        <p className="mt-6 max-w-2xl text-lg leading-8 text-white/75">
          This version sends a real SOL transfer from the connected wallet to your configured treasury wallet, then verifies the transaction through an API route.
        </p>
        <div className="mt-8 inline-flex rounded-2xl border border-fuchsia-400/25 bg-fuchsia-400/10 px-5 py-3 text-base font-semibold text-fuchsia-200">
          Next draw in:&nbsp;<Countdown targetIso={target} />
        </div>
      </div>
    </section>
  );
}
