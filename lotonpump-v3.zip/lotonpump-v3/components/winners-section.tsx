import { winners } from "@/lib/data";

export function WinnersSection() {
  return (
    <section id="winners" className="pb-16">
      <div className="mb-4 flex items-center gap-3">
        <div className="section-line" />
        <h2 className="text-center text-3xl font-black tracking-tight md:text-4xl">Recent Winners</h2>
        <div className="section-line-reverse" />
      </div>

      <p className="mx-auto mb-8 max-w-3xl text-center text-white/65">
        This section is still mock data until you connect a database.
      </p>

      <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/5">
        <div className="grid grid-cols-5 gap-2 border-b border-white/10 px-6 py-4 text-sm font-semibold uppercase tracking-[0.16em] text-white/45">
          <div>Date</div>
          <div>Draw</div>
          <div>Winner Wallet</div>
          <div>Prize</div>
          <div>Tx Proof</div>
        </div>

        {winners.map((winner) => (
          <div key={`${winner.date}-${winner.wallet}`} className="grid grid-cols-5 gap-2 px-6 py-5 text-sm text-white/80 odd:bg-white/[0.02]">
            <div>{winner.date}</div>
            <div>{winner.draw}</div>
            <div>{winner.wallet}</div>
            <div className="font-semibold text-amber-300">{winner.prize}</div>
            <div><a href={winner.proof} className="text-cyan-300 hover:text-cyan-200">View</a></div>
          </div>
        ))}
      </div>
    </section>
  );
}
