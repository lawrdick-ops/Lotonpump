export function Footer() {
  return (
    <footer className="border-t border-white/10 py-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="text-4xl font-black tracking-tight">
          <span className="bg-gradient-to-r from-amber-300 to-yellow-500 bg-clip-text text-transparent">$LOT</span>
        </div>
        <div className="flex flex-wrap gap-4 text-sm text-white/55">
          <a href="#" className="hover:text-white">Website</a>
          <a href="#" className="hover:text-white">Telegram</a>
          <a href="#" className="hover:text-white">Twitter</a>
          <a href="#" className="hover:text-white">Terms</a>
          <a href="#" className="hover:text-white">Privacy</a>
        </div>
      </div>
    </footer>
  );
}
